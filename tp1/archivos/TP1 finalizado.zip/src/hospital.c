#include "hospital.h"
#include "split.h"
#include <stdio.h>
#include <string.h>

//Agust�n de la Rosa;
//ID_ENTRENADOR1;NOMBRE_ENTRENADOR1;POKEMON1;NIVEL;POKEMON2;NIVEL;POKEMON3;NIVEL;POKEMON_n;NIVEL;

struct _hospital_pkm_t{
    size_t cantidad_entrenadores;
	size_t cantidad_pokemon;
    pokemon_t* vector_pokemones;
};

struct _pkm_t{
    char* nombre;
    size_t nivel;
};

hospital_t* hospital_crear(){
	hospital_t* hospital = calloc(1,sizeof(hospital_t));
	if(!hospital){
		return NULL;
	}
	return hospital;
}

char* fgets_dinamico(FILE *archivo){
    size_t tamanio = 0, tamanio_extra = 0;
    char linea[20]; //minimo
    char *dir_final = NULL, *temporal;

    while(fgets(linea, sizeof(linea), archivo)){

        int condicion_linea_terminada = 0;
        size_t largo_linea = strlen(linea);

        if(linea[largo_linea - 1] == '\n'){ // buffer alcanzó el tamaño
            //linea[largo_linea - 2] = 0;
            condicion_linea_terminada = 1;
        }

        if(tamanio_extra + largo_linea >= tamanio){
            tamanio += (sizeof linea) - (tamanio ? 1 : 0);
            temporal = realloc(dir_final, tamanio);
            if(temporal == NULL)
				break; 
            dir_final = temporal;
        }
        memcpy(dir_final + tamanio_extra, linea, largo_linea + 1); //le agrego memoria que me falta al buffer
        tamanio_extra += largo_linea;
        if(condicion_linea_terminada)
            break;
    }
    if(dir_final){
        temporal = realloc(dir_final, tamanio_extra + 1);
        if(temporal)
            dir_final = temporal;
    }
    return dir_final;
}

pokemon_t* ordenar_pokemones_alfabeticamente(pokemon_t* vector, size_t tope){
	if (!vector){
		return NULL;
	}
	size_t largo_cadena_j, largo_cadena_i;
	
	pokemon_t* temp = NULL;
	
	// bubble sort

    for (size_t j=0; j<tope-1; j++)
    {
        for (size_t i=j+1; i<tope; i++)
        {   	
			temp = NULL;
			if(strcmp(vector[j].nombre, vector[i].nombre) > 0){
        		largo_cadena_j = strlen(vector[j].nombre)+1;
				largo_cadena_i = strlen(vector[i].nombre)+1; //guardo sus largos antes de intercambiarlos
				
				temp = realloc(temp, sizeof(pokemon_t));
				temp->nombre = (char*)malloc(largo_cadena_j);
				strcpy(temp->nombre, vector[j].nombre);
				temp->nivel = vector[j].nivel;

				vector[j].nombre = realloc(vector[j].nombre, largo_cadena_i);
				strcpy(vector[j].nombre, vector[i].nombre);
				vector[j].nivel = vector[i].nivel;
        		
        		vector[i].nombre = realloc(vector[i].nombre, largo_cadena_j);
				strcpy(vector[i].nombre, temp->nombre);
				vector[i].nivel = temp->nivel;

				free(temp->nombre);	
				free(temp);
			}
    	}
	}
  	return vector;
}

bool hospital_leer_archivo(hospital_t* hospital, const char* nombre_archivo){
	FILE* archivo = fopen(nombre_archivo,"r");
	if (archivo == NULL){ //si la ruta da error
		return false;
	}
	size_t fila = 0, columna, i= 0;
	char* buffer = NULL;
	
	buffer = fgets_dinamico(archivo);
	while(buffer){

		columna = 0;
		fila++;

		char* valor = strtok(buffer,";");		
		
		while(valor){
			
			if (columna == 1 && *valor != '\n'){
				hospital->cantidad_entrenadores++;
			}
			if (columna>1 && columna % 2 == 0){
				hospital->cantidad_pokemon++;
				i = hospital->cantidad_pokemon - 1; // sintaxis m�s comoda, el vector est� atrasado 1 posici�n 
				hospital->vector_pokemones = realloc(hospital->vector_pokemones, sizeof(pokemon_t)*(hospital->cantidad_pokemon));
				hospital->vector_pokemones[i].nombre = (char*)malloc(strlen(valor)+1);
				strcpy(hospital->vector_pokemones[i].nombre,valor);
			}
			if (columna>1 && columna % 2 != 0){
				hospital->vector_pokemones[i].nivel = (size_t)atoi(valor);
			}
			columna++;
			valor = strtok(NULL, ";");
		}
		free(buffer);
		buffer = fgets_dinamico(archivo);
	}
	fclose(archivo);
	hospital->vector_pokemones = ordenar_pokemones_alfabeticamente(hospital->vector_pokemones,hospital->cantidad_pokemon);
	return true;
}

size_t hospital_cantidad_pokemon(hospital_t* hospital){
	if(!hospital){		
	return 0;
	}
	return hospital->cantidad_pokemon;
}

size_t hospital_cantidad_entrenadores(hospital_t* hospital){
    if(!hospital){
    	return 0;
	}
	return hospital->cantidad_entrenadores;
}

size_t hospital_a_cada_pokemon(hospital_t* hospital, bool (*funcion)(pokemon_t* p)){
    size_t cantidad = hospital_cantidad_pokemon(hospital);
    size_t i;
	pokemon_t* p = NULL;
	
	if(!funcion){
		return 0;
	}
	
	for (i = 0; i < cantidad; i++){
	 	p = &(hospital->vector_pokemones[i]);
		if(!funcion(p)){
			i++;
			return i;
		}
	}
	return i;
}

void hospital_destruir(hospital_t* hospital){
	
	if(hospital){ // al menos 1 pokemon
		size_t largo = hospital->cantidad_pokemon;
		size_t i;
		for(i=0; i < largo; i++){
			free(hospital->vector_pokemones[i].nombre);
		}
		free(hospital->vector_pokemones);
	}
	free(hospital);
}

size_t pokemon_nivel(pokemon_t* pokemon){
    if(!pokemon){
    	return 0;
    }
    return pokemon->nivel;
}

const char* pokemon_nombre(pokemon_t* pokemon){
	if(!pokemon){
    	return NULL;
    }
    return pokemon->nombre;	  
}



